




  <!--INICIO DA MODAL ESCOLAS PÚBLICAS >>> CADASTRAR -> CANDIDATO-->
      <div class="modal fade" id="modal-container-743975" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog" style="width: 400px;">
          <div class="modal-content" style="width: 400px;">
            
          <!--INÍCIO DO CABEÇALHO DA MODAL-->

          <!--FIM DO CABEÇALHO DA MODAL-->

          <!--INICIO DO CORPO DA MODAL-->
            <div class="modal-body" style="width: 400px;">
              <form class="navbar-form" role="search" action="autentica.php" method="POST">
                <div class="form-group">
                  <div class="modal-header" id="modal-header2">
                      <div class="col-xs-12 text-xs-center">
                       <h3 class="mbr-section-title display-2">SEEPS 2021</h3>
                      </div>

<!--TABELA COM AS LINHAS DA MODAL-->
      <div id="separador1">
        <input required type="text"  class="form-control" id="inputModal3" placeholder="EMAIL" name ="email" >
      </div>
      <div id="separador1">
        <input required type="text"  class="form-control" id="inputModal3" placeholder="SENHA" name ="senha" >
      </div>
      

                          
                      <div id="separadorBtn">
                        <center>
                          <button type="submit" class="btn btn-success" value="Enviar" id="btn1"><SPAN id="btnTexto">ENTRAR</SPAN></b></button>                    
                        </center>
                      </div>
                  

</div>


                    
    
                  <!--FIM DA TABELA COM AS LINHAS DA MODAL-->
                </div>                
                
            </form>
            </div>
          <!--FIM DO CORPO DA MODAL-->
          </div>
        </div>
      </div>
<!--FIM DA MODAL >>> CADASTRAR -> CADASTRAR DEMANDA-->







































