<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>SEEPS</title>
  <!-- Bootstrap core CSS-->
  <link href="../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link rel="shortcut icon" href="../assets/images/icone_salaberga.png" type="image">
  <!-- Custom fonts for this template-->
  <!-- Custom styles for this template-->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i">



    <script type="text/javascript">
      function success(){
      setTimeout("window.location='../inicio.php'", 3000);
      }
    </script> 



  <style type="text/css">

  *{
    font-family: Raleway;
        letter-spacing: 2px;
  }
  body{
    opacity: 0.8px;
  }


  .container{
    padding-top: 10%;
  }

  </style>
</head>

<body class="bg-dark">
  <div class="container" id="div1">
            <div style="width: 70%; float: center; margin-left: auto; margin-right: auto; margin-top:15%;margin-bottom:auto;" class="alert alert-dismissable alert-success">
                <h1>
                    <center>
                        Inscrição realizada com sucesso!
                    </center>
                </h1>
                <h4>
                    <center>
                        Valeu Paulim!
                    </center>
                </h4>
            </div>
  </div>
</body>

</html>


<?php
  echo "<script>success()</script>";

?>

