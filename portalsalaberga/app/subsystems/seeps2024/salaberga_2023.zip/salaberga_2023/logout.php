<?php


require_once('pdoClass/usuario.class.php');

$obj = new Usuario();
$obj->logout();



?>
